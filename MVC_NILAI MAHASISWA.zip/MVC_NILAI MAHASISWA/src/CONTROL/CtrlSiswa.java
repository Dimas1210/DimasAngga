/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CONTROL;

import MODEL.Siswa;
import VIEW.FromSiswa;

/**
 *
 * @author herlan
 */
public class CtrlSiswa {
    private Siswa sis;
    private FromSiswa tampil;
    
    public CtrlSiswa(FromSiswa tampil){
        this.tampil = tampil;
    }
    public void proses (){
        sis = new Siswa ();
        sis.setNim(tampil.getTxtNim().getText());
        sis.setNama(tampil.getTxtNama().getText());
        sis.setUh(Integer.parseInt(tampil.getTxtuh().getText()));
        sis.setUts(Integer.parseInt(tampil.getTxtuts().getText()));
        sis.setUas(Integer.parseInt(tampil.getTxtuas().getText()));
        
        sis.setRata((sis.getUh()+sis.getUts()+ sis.getUas())/3);
        
        if(sis.getRata()>=75){
            sis.setKompetensi("KOPETENSI");
        }else{
            sis.setKompetensi("TIDAK KOPETENSI");
        }
        
        tampil.getTxthasil().setText("====== INFORMASI SISWA ========\n"
                                    +"NIM : "+sis.getNim()+"\n"
                                    +"NAMA :"+sis.getNama()+"\n"
                                    +"UH :"+sis.getUh()+"\n"
                                    +"UTS :"+sis.getUts()+"\n"
                                    +"UAS :"+sis.getUas()+"\n"
                                    +"Rata-Rata :"+sis.getRata()+"\n"
                                    +"ANDA DINYATAKAN "+sis.getKompetensi()+"\n"
                                    +"===================================");  
    } 
    
    public void reset(){
        tampil.getTxtNim().setText("");
        tampil.getTxtNama().setText("");
        tampil.getTxtuh().setText("0");
        tampil.getTxtuts().setText("0");
        tampil.getTxtuas().setText("0");
        tampil.getTxthasil().setText("");
    }
}
